﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using libPhasor;

namespace SeriesExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalcVals_Click(object sender, EventArgs e)
        {
            #region check component inputs
            string r_val = RVal.Text;
            string c_val = CVal.Text;
            string l_val = LVal.Text;
            double resistor_val;
            double capacitor_val;
            double inductor_val;
            
            if (r_val.Equals("") || c_val.Equals("") || l_val.Equals(""))
            {
                MessageBox.Show("Please enter values for circuit components");
                return;
            }

            bool r_good = double.TryParse(r_val, out resistor_val);
            bool c_good = double.TryParse(c_val, out capacitor_val);
            bool l_good = double.TryParse(l_val, out inductor_val);

            if (!r_good || !c_good || !l_good || resistor_val < 0 || capacitor_val < 0 || inductor_val < 0)
            {
                MessageBox.Show("Component values must be numeric and greater than zero");
                return;
            }
            #endregion

            #region check source inputs
            string Amp = SAmp.Text;
            string Freq = SFreq.Text;
            string Phase = SPhase.Text;
            double Amp_val;
            double Freq_val;
            double Phase_val;

            if (Amp.Equals("") || Freq.Equals("") || Phase.Equals(""))
            {
                MessageBox.Show("Please enter values for circuit components");
                return;
            }

            bool Amp_good = double.TryParse(Amp, out Amp_val);
            bool Freq_good = double.TryParse(Freq, out Freq_val);
            bool Phase_good = double.TryParse(Phase, out Phase_val);

            if (!Amp_good || !Freq_good || !Phase_good || Amp_val < 0 || Freq_val < 0)
            {
                MessageBox.Show("Source values must be numeric with Amplitude and Frequency not negative.");
                return;
            }
            #endregion

            phasor r = Program.set_resistor(resistor_val);
            phasor c = Program.set_capacitor(capacitor_val, Freq_val);
            phasor l = Program.set_inductor(inductor_val, Freq_val);
            phasor s = Program.set_source(Amp_val, Phase_val);

            phasor current = s / (r + c + l);
            r.num_places = 10;
            c.num_places = 10;
            l.num_places = 10;
            s.num_places = 10;
            current.num_places = 10;
            
            TotCurrent.Text = String.Format("{0} Amps",current.ToString());
            R_Voltage.Text = String.Format("{0} V", (r * current).ToString());
            C_Voltage.Text = String.Format("{0} V", (c * current).ToString());
            L_Voltage.Text = String.Format("{0} V", (l * current).ToString());

            

        }

        private void ClearVals_Click(object sender, EventArgs e)
        {
            RVal.Text = "";
            CVal.Text = "";
            LVal.Text = "";

            SAmp.Text = "";
            SFreq.Text = "";
            SPhase.Text = "";

            TotCurrent.Text = "";
            R_Voltage.Text = "";
            C_Voltage.Text = "";
            L_Voltage.Text = "";
        }

        private void SolveMissing_Click(object sender, EventArgs e)
        {
            phasor r = new phasor();
            phasor c = new phasor();
            phasor l = new phasor();
            double resistor_val;
            double capacitor_val;
            double inductor_val;

            phasor current = new phasor();
            phasor source = new phasor();
            phasor r_volt = new phasor();
            phasor c_volt = new phasor();
            phasor l_volt = new phasor();
            
            //need to find if a value is there or not
            //for the components
                       
            
            double Amp_val;
            double Freq_val;
            double Phase_val;
            
            
            bool isROhms = double.TryParse(RVal.Text, out resistor_val);
            bool isCFarads = double.TryParse(CVal.Text, out capacitor_val);
            bool isLHenries = double.TryParse(LVal.Text, out inductor_val);
            bool isAmpVal = double.TryParse(SAmp.Text, out Amp_val);
            bool isFreqVal = double.TryParse(SFreq.Text, out Freq_val);
            bool isPhaseVal = double.TryParse(SPhase.Text, out Phase_val);
            
            bool isSourcePhasor = false;
            bool isRPhasor = false;
            bool isCPhasor = false;
            bool isLPhasor = false;

            #region create base component phasors if exist
            if (isROhms)
            {
                r = Program.set_resistor(resistor_val);
                isRPhasor = true;
            }
            if (isCFarads && isFreqVal)
            {
                c = Program.set_capacitor(capacitor_val, Freq_val);
                isCPhasor = true;
            }
            if (isLHenries && isFreqVal)
            {
                l = Program.set_inductor(inductor_val, Freq_val);
                isLPhasor = true;
            }
            if (isAmpVal && isPhaseVal)
            {
                source = Program.set_source(Amp_val, Phase_val);
                isSourcePhasor = true;
            }
            #endregion

            //now check if voltages or currents are supplied
            //assume values are in Mag,Phase format
            string RVoltage = R_Voltage.Text;
            string CVoltage = C_Voltage.Text;
            string LVoltage = L_Voltage.Text;
            string CurrentStr = TotCurrent.Text;

            bool isRVolt = true;
            bool isCVolt = true;
            bool isLVolt = true;
            bool isCurr = true;

            #region check if RVoltage has a value we can use and if it does create the appropriate phasor
            if (RVoltage.Equals(""))
            {
                isRVolt = false;
                r_volt = new phasor(0, 0, false);
            }
            else if (RVoltage.Contains(','))
            {
                //it contains it in phasor notation
                string[] phasor_parts = RVoltage.Split(',');
                double phasor_mag;
                double phasor_phase;
                bool isRVoltMag, isRVoltPhase;
                isRVoltMag = double.TryParse(phasor_parts[0], out phasor_mag);
                isRVoltPhase = double.TryParse(phasor_parts[1], out phasor_phase);

                if (isRVoltMag && isRVoltPhase)
                {
                    isRVolt = true;
                    r_volt = new phasor(phasor_mag, phasor_phase, false);
                }
                else
                {
                    isRVolt = false;
                    r_volt = new phasor(0, 0, false);
                }
            }
            else
            {
                double phasor_mag;
                isRVolt = double.TryParse(RVoltage, out phasor_mag);
                if (isRVolt)
                {
                    r_volt = new phasor(phasor_mag, 0, false);
                    isRVolt = true;
                }
                else
                {
                    r_volt = new phasor(0, 0, false);
                    isRVolt = false;
                }
            }
            #endregion

            #region check if CVoltage has a value we can use and if it does create the appropriate phasor
            if (CVoltage.Equals(""))
            {
                isCVolt = false;
                c_volt = new phasor(0, 0, false);
            }
            else if (CVoltage.Contains(','))
            {
                //it contains it in phasor notation
                string[] phasor_parts = CVoltage.Split(',');
                double phasor_mag;
                double phasor_phase;
                bool isCVoltMag, isCVoltPhase;
                isCVoltMag = double.TryParse(phasor_parts[0], out phasor_mag);
                isCVoltPhase = double.TryParse(phasor_parts[1], out phasor_phase);

                if (isCVoltMag && isCVoltPhase)
                {
                    isCVolt = true;
                    c_volt = new phasor(phasor_mag, phasor_phase, false);
                }
                else
                {
                    isCVolt = false;
                    c_volt = new phasor(0, 0, false);
                }
            }
            else
            {
                double phasor_mag;
                isCVolt = double.TryParse(CVoltage, out phasor_mag);
                if (isCVolt)
                {
                    c_volt = new phasor(phasor_mag, 0, false);
                    isCVolt = true;
                }
                else
                {
                    c_volt = new phasor(0, 0, false);
                    isCVolt = false;
                }
            }
            #endregion

            #region check if LVoltage has a value we can use and if it does create the appropriate phasor
            if (LVoltage.Equals(""))
            {
                isLVolt = false;
                l_volt = new phasor(0, 0, false);
            }
            else if (LVoltage.Contains(','))
            {
                //it contains it in phasor notation
                string[] phasor_parts = LVoltage.Split(',');
                double phasor_mag;
                double phasor_phase;
                bool isLVoltMag, isLVoltPhase;
                isLVoltMag = double.TryParse(phasor_parts[0], out phasor_mag);
                isLVoltPhase = double.TryParse(phasor_parts[1], out phasor_phase);

                if (isLVoltMag && isLVoltPhase)
                {
                    isLVolt = true;
                    l_volt = new phasor(phasor_mag, phasor_phase, false);
                }
                else
                {
                    isLVolt = false;
                    l_volt = new phasor(0, 0, false);
                }
            }
            else
            {
                double phasor_mag;
                isLVolt = double.TryParse(LVoltage, out phasor_mag);
                if (isCVolt)
                {
                    l_volt = new phasor(phasor_mag, 0, false);
                    isLVolt = true;
                }
                else
                {
                    l_volt = new phasor(0, 0, false);
                    isLVolt = false;
                }

            }
            #endregion

            #region check if current has a value we can use and if it does create the appropriate phasor
            if (CurrentStr.Equals(""))
            {
                isCurr = false;
                current = new phasor(0, 0, false);
            }
            else if (CurrentStr.Contains(','))
            {
                //it contains it in phasor notation
                string[] phasor_parts = CurrentStr.Split(',');
                double phasor_mag;
                double phasor_phase;
                bool isCurrMag, isCurrPhase;
                isCurrMag = double.TryParse(phasor_parts[0], out phasor_mag);
                isCurrPhase = double.TryParse(phasor_parts[1], out phasor_phase);

                if (isCurrMag && isCurrPhase)
                {
                    isCurr = true;
                    current = new phasor(phasor_mag, phasor_phase, false);
                }
                else
                {
                    isCurr = false;
                    current = new phasor(0, 0, false);
                }
            }
            else
            {
                double phasor_mag;
                isCurr = double.TryParse(CurrentStr, out phasor_mag);
                if (isCurr)
                {
                    current = new phasor(phasor_mag, 0, false);
                    isCurr = true;
                }
                else
                {
                    current = new phasor(0, 0, false);
                    isCurr = false;
                }
            }
            #endregion


            #region set existed at the beginning
            bool givenROhm = isROhms;
            bool givenCFarads = isCFarads;
            bool givenLHenries = isLHenries;
            bool givenRPhasor = isRPhasor;
            bool givenCPhasor = isCPhasor;
            bool givenLPhasor = isLPhasor;
            bool givenCurrent = isCurr;
            bool givenRVolt = isRVolt;
            bool givenCVolt = isCVolt;
            bool givenLVolt = isLVolt;
            bool givenSAmp = isAmpVal;
            bool givenSPhase = isPhaseVal;
            bool givenSFreq = isFreqVal;
            #endregion

            //convert boolean values into a number
            //use this order:
            //isRVal isCVal isLVal isRVolt isCVolt isLVolt isCurr isAmpVal isFreqVal isPhaseVal
            int prev_case_num = -1;
            int case_num = Program.compute_num(isROhms, isRPhasor, isCFarads, isCPhasor, isLHenries, isLPhasor, isRVolt, isCVolt, isLVolt, isCurr, isAmpVal, isFreqVal, isPhaseVal);

            //need to decide how to determine what is solvable
            while (case_num - prev_case_num != 0)
            {
                #region compute resistor region
                if (!isROhms)
                {
                    if (isRPhasor)
                    {
                        resistor_val = r.mag;
                        isROhms = true;
                    }
                    else if (isCurr && isRVolt)
                    {
                        
                        r = r_volt / current;
                        isRPhasor = true;
                        resistor_val = r.mag;
                        isROhms = true;
                    }
                    else if (isSourcePhasor && isCVolt && isLVolt && isCurr)
                    {
                        r_volt = source - c_volt - l_volt;
                        isRVolt = true;
                        r = r_volt / current;
                        resistor_val = r.mag;
                        isRPhasor = true;
                        isROhms = true;
                    }
                    else if (isCPhasor && isCVolt && isRVolt)
                    {
                        if (!isCurr)
                        {
                            current = c_volt / c;
                            r = r_volt / current;
                            isCurr = true;
                        }
                        else
                        {
                            r = r_volt / current;
                        }
                        resistor_val = r.mag;
                        isRPhasor = true;
                        isROhms = true;
                    }
                    else if (isLPhasor && isLVolt && isRVolt)
                    {
                        if (!isCurr)
                        {
                            current = l_volt / l;
                            r = r_volt / current;
                            isCurr = true;
                        }
                        else
                        {
                            r = r_volt / current;
                        }
                        resistor_val = r.mag;
                        isRPhasor = true;
                        isROhms = true;
                    }
                }
                #endregion

                #region compute capacitor val in farads
                if (!isCFarads)
                {
                    if (isCPhasor && isFreqVal)
                    {
                        capacitor_val = 1 / (c.mag * Freq_val);
                        isCFarads = true;
                    }
                }
                #endregion

                #region compute inductor val in henries
                if (!isLHenries)
                {
                    if (isLPhasor && isFreqVal)
                    {
                        inductor_val = (l.mag / Freq_val);
                        isLHenries = true;
                    }
                }
                #endregion

                #region compute current
                if (!isCurr)
                {
                    if(isLVolt && isLPhasor)
                    {
                        current = l_volt / l;
                        isCurr = true;
                    }
                    else if(isCVolt && isCPhasor)
                    {
                        current = c_volt / c;
                        isCurr = true;
                    }
                    else if (isRVolt && isRPhasor)
                    {
                        current = r_volt / r;
                        isCurr = true;
                    }
                    else if (isSourcePhasor && isRPhasor && isCPhasor && isLPhasor)
                    {
                        current = source / (r + c + l);
                        isCurr = true;
                    }
                }
                #endregion

                #region compute Amplitude
                if (!isAmpVal)
                {
                    if (isRVolt && isCVolt && isLVolt)
                    {
                        source = r_volt + l_volt + c_volt;
                        Amp_val = source.mag;
                        isAmpVal = true;
                        isSourcePhasor = true;
                        if (!isPhaseVal)
                        {
                            Phase_val = source.angle_deg;
                            isPhaseVal = true;
                        }
                    }
                    else if (isRPhasor && isCPhasor && isLPhasor && isCurr)
                    {
                        source = current * (r + c + l);
                        Amp_val = source.mag;
                        isAmpVal = true;
                        isSourcePhasor = true;
                        if (!isPhaseVal)
                        {
                            Phase_val = source.angle_deg;
                            isPhaseVal = true;
                        }
                    }
                }
                #endregion
                
                #region compute phase
                if (!isPhaseVal)
                {
                    if (isRVolt && isCVolt && isLVolt)
                    {
                        source = r_volt + l_volt + c_volt;
                        isSourcePhasor = true;
                        Phase_val = source.angle_deg;
                        isPhaseVal = true;
                    }
                    else if (isRPhasor && isCPhasor && isLPhasor && isCurr)
                    {
                        source = current * (r + c + l);
                        isSourcePhasor = true;
                        Phase_val = source.angle_deg;
                        isPhaseVal = true;
                    }
                }
                #endregion

                #region compute r_voltage
                if (!isRVolt)
                {
                    if (isRPhasor && isCurr)
                    {
                        r_volt = r * current;
                        isRVolt = true;
                    }
                    else if (isSourcePhasor && isCVolt && isLVolt)
                    {
                        r_volt = source - c_volt - l_volt;
                        isRVolt = true;
                    }
                    else if (isSourcePhasor && isRPhasor && isCPhasor && isLPhasor)
                    {
                        current = source / (r + c + l);
                        isCurr = true;
                        r_volt = current * r;
                        isRVolt = true;
                    }
                }
                #endregion

                #region compute c_voltage
                if (!isCVolt)
                {
                    if (isCPhasor && isCurr)
                    {
                        c_volt = c * current;
                        isCVolt = true;
                    }
                    else if (isAmpVal && isPhaseVal && isRVolt && isLVolt)
                    {
                        c_volt = source - r_volt - l_volt;
                        isCVolt = true;
                    }
                    else if (isAmpVal && isPhaseVal && isRPhasor && isCPhasor && isLPhasor)
                    {
                        current = source / (r + c + l);
                        isCurr = true;
                        c_volt = current * c;
                        isCVolt = true;
                    }
                }
                #endregion

                #region compute l_voltage
                if (!isLVolt)
                {
                    if (isLPhasor && isCurr)
                    {
                        l_volt = l * current;
                        isLVolt = true;
                    }
                    else if (isAmpVal && isPhaseVal && isCVolt && isRVolt)
                    {
                        l_volt = source - c_volt - r_volt;
                        isLVolt = true;
                    }
                    else if (isAmpVal && isPhaseVal && isRPhasor && isCPhasor && isLPhasor)
                    {
                        current = (source / (r + c + l));
                        isCurr = true;
                        r_volt = current * l;
                        isLVolt = true;
                    }
                }
                #endregion

                #region compute c
                if (!isCPhasor)
                {
                    if (isCFarads && isFreqVal)
                    {
                        c = Program.set_capacitor(capacitor_val, Freq_val);
                        isCPhasor = true;
                    }
                    else if(isCurr && isCVolt)
                    {
                        c = c_volt / current ;
                        isCPhasor = true;
                    }
                }
                #endregion

                #region compute l
                if (!isLPhasor)
                {
                    if (isLHenries && isFreqVal)
                    {
                        l = Program.set_inductor(inductor_val, Freq_val);
                        isLPhasor = true;
                    }
                    if (isCurr && isLVolt)
                    {
                        l = l_volt / current;
                        isLPhasor = true;
                    }
                }
                #endregion

                prev_case_num = case_num;
                case_num = Program.compute_num(isROhms, isRPhasor, isCFarads, isCPhasor, isLHenries, isLPhasor, isRVolt, isCVolt, isLVolt, isCurr, isAmpVal, isFreqVal, isPhaseVal);
            }

            r.num_places = 10;
            c.num_places = 10;
            l.num_places = 10;
            source.num_places = 10;
            current.num_places = 10;
            r_volt.num_places = 10;
            c_volt.num_places = 10;
            l_volt.num_places = 10;


            if (!givenROhm && isROhms)
                RVal.Text = resistor_val.ToString();
            else if (!givenROhm && isRPhasor)
                RVal.Text = r.mag.ToString();
            else if(!givenROhm)
                RVal.Text = "Not found.";

            if (!givenCFarads && isCFarads)
                CVal.Text = capacitor_val.ToString();
            else if (!givenCFarads && isCPhasor)
                CVal.Text = c.ToString();
            else if(!givenCFarads)
                CVal.Text = "Not found.";

            if (!givenLHenries && isLHenries)
                LVal.Text = inductor_val.ToString();
            else if (!givenLHenries && isLPhasor)
                LVal.Text = l.ToString();
            else if (!givenLHenries)
                LVal.Text = "Not found.";

            if (!givenRVolt && isRVolt)
                R_Voltage.Text = r_volt.ToString();
            else if (!givenRVolt)
                R_Voltage.Text = "Not found.";

            if (!givenCVolt && isCVolt)
                C_Voltage.Text = c_volt.ToString();
            else if (!givenCVolt)
                C_Voltage.Text = "Not found.";

            if (!givenLVolt && isLVolt)
                L_Voltage.Text = l_volt.ToString();
            else if (!givenLVolt)
                L_Voltage.Text = "Not found.";

            if (!givenSAmp && isAmpVal)
                SAmp.Text = Amp_val.ToString();
            else if (!givenSAmp && isSourcePhasor)
                SAmp.Text = source.mag.ToString();
            else if(!givenSAmp)
                SAmp.Text = "Not found.";

            if (!givenSPhase && isPhaseVal)
                SPhase.Text = Phase_val.ToString();
            else if (!givenSFreq && isSourcePhasor)
                SPhase.Text = source.angle_deg.ToString();
            else if (!givenSPhase)
                SPhase.Text = "Not found.";

            if (!givenCurrent && isCurr)
                TotCurrent.Text = current.ToString();
            else if (!givenCurrent)
                TotCurrent.Text = "Not found.";

            if (!givenSFreq)
                SFreq.Text = "Not found.";
        }
        

        

        

        
    }
}
