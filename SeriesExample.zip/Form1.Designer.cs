﻿namespace SeriesExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.RVal = new System.Windows.Forms.TextBox();
            this.CVal = new System.Windows.Forms.TextBox();
            this.LVal = new System.Windows.Forms.TextBox();
            this.SAmp = new System.Windows.Forms.TextBox();
            this.SPhase = new System.Windows.Forms.TextBox();
            this.SFreq = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.R_Voltage = new System.Windows.Forms.TextBox();
            this.C_Voltage = new System.Windows.Forms.TextBox();
            this.L_Voltage = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.TotCurrent = new System.Windows.Forms.TextBox();
            this.CalcVals = new System.Windows.Forms.Button();
            this.ClearVals = new System.Windows.Forms.Button();
            this.SolveMissing = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SeriesExample.Properties.Resources.circ;
            this.pictureBox1.Location = new System.Drawing.Point(23, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(720, 474);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(217, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "R = ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(450, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "C = ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(611, 205);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "L = ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(28, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "A = ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(28, 291);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Freq = ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(28, 372);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 20);
            this.label6.TabIndex = 1;
            this.label6.Text = "Phase = ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(55, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(667, 20);
            this.label7.TabIndex = 1;
            this.label7.Text = "All units are in standard units, frequencies are in radians, and phase is in degr" +
                "ees.";
            // 
            // RVal
            // 
            this.RVal.Location = new System.Drawing.Point(265, 85);
            this.RVal.Name = "RVal";
            this.RVal.Size = new System.Drawing.Size(100, 20);
            this.RVal.TabIndex = 1;
            // 
            // CVal
            // 
            this.CVal.Location = new System.Drawing.Point(497, 83);
            this.CVal.Name = "CVal";
            this.CVal.Size = new System.Drawing.Size(100, 20);
            this.CVal.TabIndex = 2;
            // 
            // LVal
            // 
            this.LVal.Location = new System.Drawing.Point(656, 205);
            this.LVal.Name = "LVal";
            this.LVal.Size = new System.Drawing.Size(77, 20);
            this.LVal.TabIndex = 3;
            // 
            // SAmp
            // 
            this.SAmp.Location = new System.Drawing.Point(75, 176);
            this.SAmp.Name = "SAmp";
            this.SAmp.Size = new System.Drawing.Size(64, 20);
            this.SAmp.TabIndex = 4;
            // 
            // SPhase
            // 
            this.SPhase.Location = new System.Drawing.Point(75, 395);
            this.SPhase.Name = "SPhase";
            this.SPhase.Size = new System.Drawing.Size(64, 20);
            this.SPhase.TabIndex = 6;
            // 
            // SFreq
            // 
            this.SFreq.Location = new System.Drawing.Point(75, 314);
            this.SFreq.Name = "SFreq";
            this.SFreq.Size = new System.Drawing.Size(64, 20);
            this.SFreq.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(240, 174);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 20);
            this.label8.TabIndex = 1;
            this.label8.Text = "+  R_Voltage -";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(411, 176);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(124, 20);
            this.label9.TabIndex = 1;
            this.label9.Text = "+  C_Voltage -";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(450, 242);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 20);
            this.label10.TabIndex = 1;
            this.label10.Text = "+L_Voltage -";
            // 
            // R_Voltage
            // 
            this.R_Voltage.Location = new System.Drawing.Point(244, 197);
            this.R_Voltage.Name = "R_Voltage";
            this.R_Voltage.Size = new System.Drawing.Size(100, 20);
            this.R_Voltage.TabIndex = 2;
            this.R_Voltage.TabStop = false;
            // 
            // C_Voltage
            // 
            this.C_Voltage.Location = new System.Drawing.Point(415, 197);
            this.C_Voltage.Name = "C_Voltage";
            this.C_Voltage.Size = new System.Drawing.Size(100, 20);
            this.C_Voltage.TabIndex = 2;
            this.C_Voltage.TabStop = false;
            // 
            // L_Voltage
            // 
            this.L_Voltage.Location = new System.Drawing.Point(454, 265);
            this.L_Voltage.Name = "L_Voltage";
            this.L_Voltage.Size = new System.Drawing.Size(108, 20);
            this.L_Voltage.TabIndex = 2;
            this.L_Voltage.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(193, 330);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(134, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "Total Current = ";
            // 
            // TotCurrent
            // 
            this.TotCurrent.Location = new System.Drawing.Point(333, 332);
            this.TotCurrent.Name = "TotCurrent";
            this.TotCurrent.Size = new System.Drawing.Size(99, 20);
            this.TotCurrent.TabIndex = 2;
            this.TotCurrent.TabStop = false;
            // 
            // CalcVals
            // 
            this.CalcVals.Location = new System.Drawing.Point(474, 408);
            this.CalcVals.Name = "CalcVals";
            this.CalcVals.Size = new System.Drawing.Size(123, 46);
            this.CalcVals.TabIndex = 7;
            this.CalcVals.Text = "Solve Voltages and Current";
            this.CalcVals.UseVisualStyleBackColor = true;
            this.CalcVals.Click += new System.EventHandler(this.CalcVals_Click);
            // 
            // ClearVals
            // 
            this.ClearVals.Location = new System.Drawing.Point(333, 408);
            this.ClearVals.Name = "ClearVals";
            this.ClearVals.Size = new System.Drawing.Size(123, 46);
            this.ClearVals.TabIndex = 8;
            this.ClearVals.Text = "Clear Circuit";
            this.ClearVals.UseVisualStyleBackColor = true;
            this.ClearVals.Click += new System.EventHandler(this.ClearVals_Click);
            // 
            // SolveMissing
            // 
            this.SolveMissing.Location = new System.Drawing.Point(610, 408);
            this.SolveMissing.Name = "SolveMissing";
            this.SolveMissing.Size = new System.Drawing.Size(123, 46);
            this.SolveMissing.TabIndex = 9;
            this.SolveMissing.Text = "Solve For Missing Values";
            this.SolveMissing.UseVisualStyleBackColor = true;
            this.SolveMissing.Click += new System.EventHandler(this.SolveMissing_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 498);
            this.Controls.Add(this.SolveMissing);
            this.Controls.Add(this.ClearVals);
            this.Controls.Add(this.CalcVals);
            this.Controls.Add(this.SFreq);
            this.Controls.Add(this.SPhase);
            this.Controls.Add(this.SAmp);
            this.Controls.Add(this.TotCurrent);
            this.Controls.Add(this.L_Voltage);
            this.Controls.Add(this.LVal);
            this.Controls.Add(this.C_Voltage);
            this.Controls.Add(this.CVal);
            this.Controls.Add(this.R_Voltage);
            this.Controls.Add(this.RVal);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox RVal;
        private System.Windows.Forms.TextBox CVal;
        private System.Windows.Forms.TextBox LVal;
        private System.Windows.Forms.TextBox SAmp;
        private System.Windows.Forms.TextBox SPhase;
        private System.Windows.Forms.TextBox SFreq;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox R_Voltage;
        private System.Windows.Forms.TextBox C_Voltage;
        private System.Windows.Forms.TextBox L_Voltage;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox TotCurrent;
        private System.Windows.Forms.Button CalcVals;
        private System.Windows.Forms.Button ClearVals;
        private System.Windows.Forms.Button SolveMissing;
    }
}

