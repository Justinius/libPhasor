﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using libPhasor;

namespace SeriesExample
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }

        static public phasor set_resistor(double resistor_val)
        {
            return new phasor(resistor_val, 0, false);
        }

        static public phasor set_capacitor(double val_in_farads, double freq_in_rads)
        {
            return new phasor((1.0 / (val_in_farads * freq_in_rads)), -90, false);
        }

        static public phasor set_inductor(double val_in_henries, double freq_in_rads)
        {
            return new phasor(val_in_henries * freq_in_rads, 90, false);
        }

        static public phasor set_source(double Amplitude, double phase)
        {
            return new phasor(Amplitude, phase, false);
        }

        static public int compute_num(bool a, bool b, bool c, bool d, bool e, bool f, bool g, bool h, bool i, bool j, bool k, bool l, bool m)
        {
            int output = 0;
            if (a)
                output += 4096;
            if (b)
                output += 2048;
            if (c)
                output += 1024;
            if (d)
                output += 512;
            if (e)
                output += 256;
            if (f)
                output += 128;
            if (g)
                output += 64;
            if (h)
                output += 32;
            if (i)
                output += 16;
            if (j)
                output += 8;
            if (k)
                output += 4;
            if(l)
                output += 2;
            if(m)
                output += 1;


            return output;
        }
    }
}
